//
// Validator.cpp
//
// Library: Util
// Package: Options
// Module:  Validator
//
// Copyright (c) 2006, Applied Informatics Software Engineering GmbH.
// and Contributors.
//
// SPDX-License-Identifier:	BSL-1.0
//


#include "Poco/Util/Validator.h"


namespace Poco {
namespace Util {


Validator::Validator()
{
}


Validator::~Validator()
{
}


} } // namespace Poco::Util
